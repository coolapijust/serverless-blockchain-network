# Cloudflare Serverless Blockchain MVP

基于 Cloudflare 边缘计算的极简区块链实现，采用事件驱动架构实现"零交易零成本，有交易即时出块"。

## 架构概览

```
用户提交交易 → API Worker → 写入 DO Pending Queue → HTTP 唤醒 Proposer → 打包区块 → 并行请求 2 Validators 签名 → 收集 2/3 签名 → DO 原子提交 → 清空 Queue
```

## 核心特性

- **零成本休眠**：无交易时 Workers 完全休眠，不消耗任何资源
- **3秒确认**：交易提交后 3 秒内完成 BFT 共识确认
- **强一致性**：Pending Queue 使用 Durable Objects 存储，防止双花攻击
- **事件驱动**：禁用 Cron Triggers，完全由交易提交事件驱动
- **Alarm 兜底**：5 分钟超时强制出块，防止交易卡死
- **批量打包**：单次出块可包含 1-20 笔交易，降低单位成本

## 系统架构

### 关键组件

| 组件 | 类型 | 职责 |
|------|------|------|
| API Gateway | Worker | 接收交易、验签、写入 DO Queue、触发 Proposer |
| Proposer | Worker | 批量打包、并行收集签名、原子提交 |
| Validator x2 | Worker | 无状态验签、区块验证 |
| ConsensusCoordinator | Durable Object | 存储 World State、Pending Queue、原子提交 |

### 数据流

```
┌─────────────┐     ┌─────────────┐     ┌─────────────────────────┐
│   Client    │────▶│  API Worker │────▶│  ConsensusCoordinator   │
└─────────────┘     └─────────────┘     │  (Durable Object)       │
                                        │  - Pending Queue         │
                                        │  - World State           │
                                        └─────────────────────────┘
                                                      │
                       ┌──────────────────────────────┘
                       ▼
              ┌─────────────────┐
              │     Proposer    │
              │    (Worker)     │
              └────────┬────────┘
                       │
         ┌─────────────┼─────────────┐
         ▼             ▼             ▼
   ┌──────────┐  ┌──────────┐  ┌──────────┐
   │Validator1│  │Validator2│  │  (备用)  │
   │ (Worker) │  │ (Worker) │  │          │
   └──────────┘  └──────────┘  └──────────┘
```

## 项目结构

```
blockchain-mvp/
├── wrangler.toml                    # Cloudflare 配置
├── src/
│   ├── types.ts                     # TypeScript 类型定义
│   ├── crypto.ts                    # Ed25519 + SHA-256 工具
│   ├── durable-objects/
│   │   └── consensus.ts             # ConsensusCoordinator DO
│   └── workers/
│       ├── api.ts                   # API Gateway
│       ├── proposer.ts              # 区块提议者
│       └── validator.ts             # 验证者节点
└── test/
    └── scenarios.ts                 # 测试用例
```

## 部署方案

### 前置要求

1. [Cloudflare 账号](https://dash.cloudflare.com/sign-up)
2. [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/install-and-update/) 安装
3. Node.js 18+

### 1. 初始化项目

```bash
# 克隆代码
git clone <repository>
cd blockchain-mvp

# 安装依赖
npm install

# 登录 Cloudflare
wrangler login
```

### 2. 创建 KV Namespace

```bash
# 创建配置存储（仅用于配置，不用于队列）
wrangler kv:namespace create "CONFIG_KV"
wrangler kv:namespace create "CONFIG_KV" --preview

# 记录输出的 id 和 preview_id，更新 wrangler.toml
```

### 3. 生成 Ed25519 密钥

```bash
# 生成 3 组密钥（Proposer + 2 Validators）
node -e "
const crypto = require('crypto');
for (let i = 0; i < 3; i++) {
  const keypair = crypto.generateKeyPairSync('ed25519');
  const privateKey = keypair.privateKey.export({ type: 'pkcs8', format: 'der' }).toString('hex').slice(32, 96);
  const publicKey = keypair.publicKey.export({ type: 'spki', format: 'der' }).toString('hex').slice(24, 88);
  console.log('KeyPair ' + i + ':');
  console.log('  Private:', '0x' + privateKey);
  console.log('  Public:', '0x' + publicKey);
  console.log('  Address:', '0x' + publicKey.slice(0, 40));
}
"
```

### 4. 配置 Secrets

```bash
# Proposer 私钥
wrangler secret put PROPOSER_PRIVATE_KEY --env proposer
# 输入: 0x0123456789abcdef...

# Validator 1 私钥
wrangler secret put VALIDATOR_PRIVATE_KEY --env validator1
# 输入: 0xfedcba9876543210...

# Validator 2 私钥
wrangler secret put VALIDATOR_PRIVATE_KEY --env validator2
# 输入: 0xaabbccdd11223344...
```

### 5. 部署 Workers

```bash
# 部署 API Gateway
wrangler deploy --env production

# 部署 Proposer
wrangler deploy --env proposer

# 部署 Validator 1
wrangler deploy --env validator1

# 部署 Validator 2
wrangler deploy --env validator2
```

### 6. 配置自定义域名（可选）

```bash
# 添加路由
wrangler route add api.your-domain.com/* --script blockchain-mvp
wrangler route add proposer.your-domain.com/* --script blockchain-mvp-proposer
wrangler route add validator1.your-domain.com/* --script blockchain-mvp-validator1
wrangler route add validator2.your-domain.com/* --script blockchain-mvp-validator2
```

## 运行状态检查

### 1. 健康检查

```bash
# API Gateway
curl https://api.blockchain-mvp.workers.dev/health

# Proposer
curl https://proposer.blockchain-mvp.workers.dev/health

# Validators
curl https://validator1.blockchain-mvp.workers.dev/health
curl https://validator2.blockchain-mvp.workers.dev/health
```

**预期响应：**
```json
{
  "status": "ok",
  "service": "blockchain-api",
  "requestId": "xxx"
}
```

### 2. 网络状态

```bash
curl https://api.blockchain-mvp.workers.dev/status
```

**预期响应：**
```json
{
  "success": true,
  "data": {
    "networkId": "cloudflare-mvp-testnet",
    "chainId": "1337",
    "latestBlockHeight": 0,
    "latestBlockHash": "0x0000...",
    "pendingTransactions": 0,
    "totalTransactions": 0,
    "validators": []
  }
}
```

### 3. DO 状态检查

```bash
# 查询 ConsensusCoordinator 状态
curl https://api.blockchain-mvp.workers.dev/internal/state
```

**预期响应：**
```json
{
  "worldState": {
    "balances": {},
    "nonces": {},
    "latestBlockHeight": 0,
    "latestBlockHash": "0x0000...",
    "totalTransactions": 0
  },
  "pendingCount": 0,
  "processing": false,
  "consensusState": "idle"
}
```

### 4. 端到端交易测试

```bash
# 1. 获取测试代币（开发网）
curl -X POST https://api.blockchain-mvp.workers.dev/faucet \
  -H "Content-Type: application/json" \
  -d '{"address":"0x0123456789abcdef0123456789abcdef01234567"}'

# 2. 查询账户余额
curl https://api.blockchain-mvp.workers.dev/account/0x0123456789abcdef0123456789abcdef01234567

# 3. 提交交易（需要先签名）
curl -X POST https://api.blockchain-mvp.workers.dev/tx/submit \
  -H "Content-Type: application/json" \
  -d '{
    "from": "0x0123456789abcdef0123456789abcdef01234567",
    "to": "0xfedcba9876543210fedcba9876543210fedcba98",
    "amount": "100",
    "nonce": 0,
    "signature": "0x..."
  }'

# 4. 查询交易状态
curl https://api.blockchain-mvp.workers.dev/tx/0x...

# 5. 查询最新区块
curl https://api.blockchain-mvp.workers.dev/block/latest
```

### 5. 性能测试

```bash
# 批量提交交易
for i in {1..20}; do
  curl -X POST https://api.blockchain-mvp.workers.dev/tx/submit \
    -H "Content-Type: application/json" \
    -d "{\"from\":\"0x...\",\"to\":\"0x...\",\"amount\":\"1\",\"nonce\":$i,\"signature\":\"0x...\"}" &
done
wait

# 等待确认后查询
sleep 5
curl https://api.blockchain-mvp.workers.dev/status
```

### 6. 监控指标

```bash
# 查看 Workers 日志
wrangler tail --env production

# 查看 Proposer 日志
wrangler tail --env proposer

# 查看 Validator 日志
wrangler tail --env validator1
```

## 关键设计决策

### 为什么 Pending Queue 必须用 Durable Objects？

| 特性 | Durable Objects | KV |
|------|----------------|-----|
| 一致性 | 强一致 | 最终一致（~60秒） |
| 并发控制 | 支持（storage.transaction） | 不支持 |
| 双花风险 | 无 | 高（并发写入同一 key） |
| 适用场景 | 队列、状态 | 配置、缓存 |

**结论：** 队列需要强一致性和并发控制，必须用 DO。

### 为什么禁用 Cron Triggers？

- **成本**：Cron 会定期唤醒 Worker，产生费用
- **延迟**：固定间隔无法满足"即时出块"需求
- **设计目标**："零交易零成本"要求完全事件驱动

### 为什么使用 Alarm 兜底？

- **故障恢复**：Proposer 崩溃后 Alarm 自动触发
- **防卡死**：长时间未出块时强制处理
- **成本可控**：Alarm 只在需要时触发

## 故障排查

### 问题：交易提交后长时间未确认

**排查步骤：**

1. 检查 API 日志：`wrangler tail --env production`
2. 检查 Proposer 是否被触发：`wrangler tail --env proposer`
3. 检查 DO 状态：`curl /internal/state`
4. 手动触发 Proposer：`curl -X POST /trigger`

### 问题：双花攻击成功

**可能原因：**

1. Pending Queue 使用了 KV 而非 DO
2. `processing` 锁未正确实现
3. `storage.transaction` 未使用

**检查点：**

```typescript
// 确保 DO 中使用原子事务
await this.state.storage.transaction(async (txn) => {
  // 所有状态变更必须在此完成
});
```

### 问题：Validator 返回无效签名

**排查步骤：**

1. 检查 Validator 密钥配置：`wrangler secret list --env validator1`
2. 检查区块哈希计算是否正确
3. 检查签名数据格式

## 安全建议

1. **密钥管理**：生产环境使用 Cloudflare Secrets，禁止硬编码
2. **访问控制**：Proposer `/internal/*` 接口限制 IP 访问
3. **速率限制**：API Gateway 添加请求限流
4. **监控告警**：配置异常交易告警

## 扩展方向

1. **分片**：多个 DO 实例处理不同地址范围
2. **跨链桥**：添加与其他链的桥接合约
3. **智能合约**：集成 WASM 运行时
4. **隐私交易**：添加零知识证明支持

## 许可证

MIT
