/**
 * ============================================
 * Cloudflare Serverless Blockchain MVP
 * API Gateway Worker
 * ============================================
 * 
 * 核心职责：
 * 1. 接收交易提交（POST /tx/submit）
 * 2. 验签 + Nonce 防重放检查
 * 3. 写入 DO Pending Queue（强一致）
  * 4. 立即 HTTP POST 唤醒 Proposer（事件驱动）
 * 5. 提供查询接口（账户、区块、交易）
 * 
 * 设计原则：
 * - 所有写操作通过 DO 原子事务
 * - 提交后立即触发共识（无延迟）
 * - 返回预估确认时间（3秒内）
 */

import type {
  Transaction,
  SubmitTransactionRequest,
  SubmitTransactionResponse,
  ApiResponse,
  NetworkStatusResponse,
  AccountQueryResponse,
  TransactionReceipt,
  ApiEnv,
  Address,
  HexString,
} from '../types';

import {
  hashTransaction,
  verifySignature,
  signTransaction,
  publicKeyToAddress,
  addHexPrefix,
  generateRandomPrivateKey,
  getTestKeyPair,
} from '../crypto';

// ============================================
// CORS 响应头
// ============================================

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

// ============================================
// 主处理函数
// ============================================

export default {
  async fetch(request: Request, env: ApiEnv): Promise<Response> {
    // 处理 CORS 预检
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }
    
    const url = new URL(request.url);
    const path = url.pathname;
    
    // 生成请求 ID
    const requestId = crypto.randomUUID();
    
    try {
      // 健康检查
      if (path === '/health') {
        return jsonResponse({ status: 'ok', service: 'blockchain-api', requestId });
      }
      
      // 提交交易
      if (path === '/tx/submit' && request.method === 'POST') {
        return handleSubmitTransaction(request, env, requestId);
      }
      
      // 查询交易
      if (path.startsWith('/tx/') && request.method === 'GET') {
        const txHash = path.split('/')[2];
        return handleQueryTransaction(txHash, env, requestId);
      }
      
      // 查询账户
      if (path.startsWith('/account/') && request.method === 'GET') {
        const address = path.split('/')[2];
        return handleQueryAccount(address, env, requestId);
      }
      
      // 查询区块
      if (path.startsWith('/block/') && request.method === 'GET') {
        const heightOrHash = path.split('/')[2];
        return handleQueryBlock(heightOrHash, env, requestId);
      }
      
      // 查询最新区块
      if (path === '/block/latest' && request.method === 'GET') {
        return handleQueryLatestBlock(env, requestId);
      }
      
      // 网络状态
      if (path === '/status' && request.method === 'GET') {
        return handleNetworkStatus(env, requestId);
      }
      
      // 获取测试代币（仅测试网）
      if (path === '/faucet' && request.method === 'POST') {
        return handleFaucet(request, env, requestId);
      }
      
      return jsonResponse({ error: 'Not found', requestId }, 404);
      
    } catch (error) {
      console.error('[API] Error:', error);
      return jsonResponse({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error',
        requestId,
      }, 500);
    }
  },
};

// ============================================
// 交易提交处理
// ============================================

async function handleSubmitTransaction(
  request: Request,
  env: ApiEnv,
  requestId: string
): Promise<Response> {
  const startTime = Date.now();
  
  // 解析请求
  const body = await request.json() as SubmitTransactionRequest;
  
  // 验证必填字段
  if (!body.from || !body.to || !body.signature) {
    return jsonResponse({
      success: false,
      error: 'Missing required fields: from, to, signature',
      requestId,
    }, 400);
  }
  
  // 验证地址格式
  if (!isValidAddress(body.from) || !isValidAddress(body.to)) {
    return jsonResponse({
      success: false,
      error: 'Invalid address format',
      requestId,
    }, 400);
  }
  
  // 构建交易对象
  const tx: Transaction = {
    hash: '', // 稍后计算
    from: body.from.toLowerCase(),
    to: body.to.toLowerCase(),
    amount: BigInt(body.amount || '0'),
    nonce: body.nonce,
    timestamp: body.timestamp || Date.now(),
    gasPrice: BigInt(0),
    gasLimit: BigInt(21000),
    signature: body.signature,
  };
  
  // 计算交易哈希
  tx.hash = await hashTransaction({
    from: tx.from,
    to: tx.to,
    amount: tx.amount.toString(),
    nonce: tx.nonce,
    timestamp: tx.timestamp,
    gasPrice: tx.gasPrice.toString(),
    gasLimit: tx.gasLimit.toString(),
  });
  
  // 验证签名（防重放攻击）
  // 注意：实际实现需要从地址恢复公钥
  // 这里简化处理，假设签名格式正确
  
  console.log('[API] Submitting transaction:', {
    hash: tx.hash,
    from: tx.from,
    to: tx.to,
    amount: tx.amount.toString(),
    nonce: tx.nonce,
  });
  
  // 获取 DO stub
  const doId = env.CONSENSUS_COORDINATOR.idFromName('consensus-coordinator');
  const doStub = env.CONSENSUS_COORDINATOR.get(doId);
  
  // 写入 Pending Queue
  const addResult = await addTransactionToQueue(doStub, tx);
  
  if (!addResult.success) {
    return jsonResponse({
      success: false,
      error: addResult.error,
      requestId,
    }, 400);
  }
  
  console.log('[API] Transaction added to queue:', tx.hash);
  
  // 立即触发 Proposer（事件驱动关键）
  // 使用 waitUntil 确保触发在后台执行，不阻塞响应
  const triggerPromise = triggerProposer(env);
  
  // 等待触发完成（或超时）
  const triggerTimeout = 2000; // 2 秒超时
  const triggerResult = await Promise.race([
    triggerPromise,
    new Promise<{ triggered: boolean; error?: string }>((resolve) => {
      setTimeout(() => resolve({ triggered: false, error: 'Trigger timeout' }), triggerTimeout);
    }),
  ]);
  
  console.log('[API] Proposer trigger result:', triggerResult);
  
  const processingTime = Date.now() - startTime;
  
  // 返回响应
  const response: SubmitTransactionResponse = {
    success: true,
    txHash: tx.hash,
    blockHeight: undefined, // 尚未确认
    estimatedConfirmationTime: 3000, // 预估 3 秒
  };
  
  return jsonResponse({
    ...response,
    processingTimeMs: processingTime,
    triggerStatus: triggerResult.triggered ? 'success' : 'pending',
    requestId,
  });
}

// ============================================
// 查询接口
// ============================================

async function handleQueryTransaction(
  txHash: HexString,
  env: ApiEnv,
  requestId: string
): Promise<Response> {
  const doId = env.CONSENSUS_COORDINATOR.idFromName('consensus-coordinator');
  const doStub = env.CONSENSUS_COORDINATOR.get(doId);
  
  const receipt = await queryTransaction(doStub, txHash);
  
  if (!receipt) {
    return jsonResponse({
      success: false,
      error: 'Transaction not found',
      requestId,
    }, 404);
  }
  
  return jsonResponse({
    success: true,
    data: {
      ...receipt,
      transaction: {
        ...receipt.transaction,
        amount: receipt.transaction.amount.toString(),
        gasPrice: receipt.transaction.gasPrice.toString(),
        gasLimit: receipt.transaction.gasLimit.toString(),
      },
    },
    requestId,
  });
}

async function handleQueryAccount(
  address: Address,
  env: ApiEnv,
  requestId: string
): Promise<Response> {
  const doId = env.CONSENSUS_COORDINATOR.idFromName('consensus-coordinator');
  const doStub = env.CONSENSUS_COORDINATOR.get(doId);
  
  const account = await queryAccount(doStub, address.toLowerCase());
  const pendingNonce = await getPendingNonce(doStub, address.toLowerCase());
  
  const response: AccountQueryResponse = {
    address: address.toLowerCase(),
    balance: account.balance.toString(),
    nonce: account.nonce,
    pendingNonce,
  };
  
  return jsonResponse({
    success: true,
    data: response,
    requestId,
  });
}

async function handleQueryBlock(
  heightOrHash: string,
  env: ApiEnv,
  requestId: string
): Promise<Response> {
  const doId = env.CONSENSUS_COORDINATOR.idFromName('consensus-coordinator');
  const doStub = env.CONSENSUS_COORDINATOR.get(doId);
  
  // 判断是高度还是哈希
  const isHeight = /^\d+$/.test(heightOrHash);
  
  let block;
  if (isHeight) {
    block = await queryBlockByHeight(doStub, parseInt(heightOrHash));
  } else {
    // 通过哈希查询需要遍历，这里简化
    return jsonResponse({
      success: false,
      error: 'Query by hash not implemented',
      requestId,
    }, 501);
  }
  
  if (!block) {
    return jsonResponse({
      success: false,
      error: 'Block not found',
      requestId,
    }, 404);
  }
  
  return jsonResponse({
    success: true,
    data: block,
    requestId,
  });
}

async function handleQueryLatestBlock(
  env: ApiEnv,
  requestId: string
): Promise<Response> {
  const doId = env.CONSENSUS_COORDINATOR.idFromName('consensus-coordinator');
  const doStub = env.CONSENSUS_COORDINATOR.get(doId);
  
  const latest = await queryLatestBlock(doStub);
  
  return jsonResponse({
    success: true,
    data: latest,
    requestId,
  });
}

async function handleNetworkStatus(
  env: ApiEnv,
  requestId: string
): Promise<Response> {
  const doId = env.CONSENSUS_COORDINATOR.idFromName('consensus-coordinator');
  const doStub = env.CONSENSUS_COORDINATOR.get(doId);
  
  const state = await queryState(doStub);
  
  const response: NetworkStatusResponse = {
    networkId: env.NETWORK_ID || 'unknown',
    chainId: env.CHAIN_ID || '0',
    latestBlockHeight: state.worldState.latestBlockHeight,
    latestBlockHash: state.worldState.latestBlockHash,
    pendingTransactions: state.pendingCount,
    totalTransactions: state.worldState.totalTransactions,
    validators: [], // 从配置获取
    uptime: 0, // 需要额外统计
  };
  
  return jsonResponse({
    success: true,
    data: response,
    requestId,
  });
}

// ============================================
// 测试水龙头
// ============================================

async function handleFaucet(
  request: Request,
  env: ApiEnv,
  requestId: string
): Promise<Response> {
  // 仅测试网可用
  if (env.NETWORK_ID !== 'cloudflare-mvp-devnet') {
    return jsonResponse({
      success: false,
      error: 'Faucet only available on devnet',
      requestId,
    }, 403);
  }
  
  const body = await request.json() as { address: string };
  
  if (!body.address || !isValidAddress(body.address)) {
    return jsonResponse({
      success: false,
      error: 'Invalid address',
      requestId,
    }, 400);
  }
  
  // 使用测试密钥签名水龙头交易
  const faucetKey = getTestKeyPair(0);
  const timestamp = Date.now();
  
  const txData = {
    from: publicKeyToAddress(faucetKey.publicKey),
    to: body.address.toLowerCase(),
    amount: '1000000000000000000', // 1 token
    nonce: 0, // 水龙头使用固定 nonce
    timestamp,
  };
  
  const signature = await signTransaction(txData, faucetKey.privateKey);
  
  // 构建完整交易
  const tx: Transaction = {
    hash: '',
    from: txData.from,
    to: txData.to,
    amount: BigInt(txData.amount),
    nonce: txData.nonce,
    timestamp,
    gasPrice: BigInt(0),
    gasLimit: BigInt(21000),
    signature,
  };
  
  tx.hash = await hashTransaction({
    from: tx.from,
    to: tx.to,
    amount: tx.amount.toString(),
    nonce: tx.nonce,
    timestamp: tx.timestamp,
    gasPrice: tx.gasPrice.toString(),
    gasLimit: tx.gasLimit.toString(),
  });
  
  // 提交到队列
  const doId = env.CONSENSUS_COORDINATOR.idFromName('consensus-coordinator');
  const doStub = env.CONSENSUS_COORDINATOR.get(doId);
  
  const addResult = await addTransactionToQueue(doStub, tx);
  
  if (!addResult.success) {
    return jsonResponse({
      success: false,
      error: addResult.error,
      requestId,
    }, 500);
  }
  
  // 触发 Proposer
  triggerProposer(env).catch(console.error);
  
  return jsonResponse({
    success: true,
    data: {
      txHash: tx.hash,
      amount: txData.amount,
      to: txData.to,
    },
    requestId,
  });
}

// ============================================
// DO 操作封装
// ============================================

async function addTransactionToQueue(
  doStub: DurableObjectStub,
  tx: Transaction
): Promise<{ success: boolean; error?: string }> {
  const response = await doStub.fetch('http://internal/add-tx', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(tx),
  });
  
  return response.json() as Promise<{ success: boolean; error?: string }>;
}

async function queryTransaction(
  doStub: DurableObjectStub,
  txHash: HexString
): Promise<TransactionReceipt | null> {
  const response = await doStub.fetch(`http://internal/tx/${txHash}`, {
    method: 'GET',
  });
  
  if (!response.ok) return null;
  
  const result = await response.json();
  if (result.error) return null;
  
  return result as TransactionReceipt;
}

async function queryAccount(
  doStub: DurableObjectStub,
  address: Address
): Promise<{ balance: bigint; nonce: number }> {
  const response = await doStub.fetch(`http://internal/account/${address}`, {
    method: 'GET',
  });
  
  const result = await response.json() as { balance: string; nonce: number };
  
  return {
    balance: BigInt(result.balance),
    nonce: result.nonce,
  };
}

async function getPendingNonce(doStub: DurableObjectStub, address: Address): Promise<number> {
  // 查询 Pending Queue 中该地址的交易
  const response = await doStub.fetch('http://internal/queue', {
    method: 'GET',
  });
  
  const result = await response.json() as { transactions: Transaction[] };
  
  // 找到该地址的最大 nonce
  const addressTxs = result.transactions.filter(tx => tx.from === address);
  if (addressTxs.length === 0) {
    const account = await queryAccount(doStub, address);
    return account.nonce;
  }
  
  const maxNonce = Math.max(...addressTxs.map(tx => tx.nonce));
  return maxNonce + 1;
}

async function queryBlockByHeight(
  doStub: DurableObjectStub,
  height: number
): Promise<unknown | null> {
  const response = await doStub.fetch(`http://internal/block/${height}`, {
    method: 'GET',
  });
  
  if (!response.ok) return null;
  
  const result = await response.json();
  if (result.error) return null;
  
  return result;
}

async function queryLatestBlock(
  doStub: DurableObjectStub
): Promise<{ height: number; hash: string; timestamp: number }> {
  const response = await doStub.fetch('http://internal/block/latest', {
    method: 'GET',
  });
  
  return response.json() as Promise<{ height: number; hash: string; timestamp: number }>;
}

async function queryState(doStub: DurableObjectStub): Promise<{
  worldState: { latestBlockHeight: number; latestBlockHash: string; totalTransactions: number };
  pendingCount: number;
}> {
  const response = await doStub.fetch('http://internal/state', {
    method: 'GET',
  });
  
  return response.json() as Promise<{
    worldState: { latestBlockHeight: number; latestBlockHash: string; totalTransactions: number };
    pendingCount: number;
  }>;
}

// ============================================
// Proposer 触发
// ============================================

async function triggerProposer(env: ApiEnv): Promise<{ triggered: boolean; error?: string }> {
  try {
    const proposerUrl = env.PROPOSER_URL;
    
    if (!proposerUrl) {
      return { triggered: false, error: 'Proposer URL not configured' };
    }
    
    // HTTP POST 唤醒 Proposer
    const response = await fetch(`${proposerUrl}/internal/trigger`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'X-Trigger-Source': 'api-gateway',
      },
      body: JSON.stringify({ timestamp: Date.now() }),
    });
    
    if (!response.ok) {
      const error = await response.text();
      console.error('[API] Proposer trigger failed:', error);
      return { triggered: false, error: `HTTP ${response.status}: ${error}` };
    }
    
    const result = await response.json();
    console.log('[API] Proposer triggered successfully:', result);
    
    return { triggered: true };
    
  } catch (error) {
    console.error('[API] Proposer trigger error:', error);
    return { 
      triggered: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    };
  }
}

// ============================================
// 工具函数
// ============================================

function jsonResponse(data: unknown, status: number = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...corsHeaders,
    },
  });
}

function isValidAddress(address: string): boolean {
  if (!address) return false;
  
  const clean = address.startsWith('0x') ? address.slice(2) : address;
  
  if (clean.length !== 40) return false;
  
  return /^[0-9a-fA-F]+$/.test(clean);
}
