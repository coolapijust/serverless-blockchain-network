/**
 * ============================================
 * Wallet Page
 * ============================================
 */

import { useState } from 'react';
import { 
  Wallet as WalletIcon, 
  Copy, 
  Send, 
  History,
  QrCode,
  Key,
  AlertTriangle,
  ExternalLink
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useWallet } from '@/contexts/WalletContext';
import { api } from '@/lib/api';
import { shortenAddress, formatAmount, formatTimestamp } from '@/lib/crypto';
import type { Transaction } from '@/types';

const MOCK_TRANSACTIONS: Transaction[] = [
  {
    hash: '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef',
    from: '0x0123456789abcdef0123456789abcdef01234567',
    to: '0xfedcba9876543210fedcba9876543210fedcba98',
    amount: '1000000000000000000',
    nonce: 0,
    timestamp: Date.now() - 3600000,
    gasPrice: '0',
    gasLimit: '21000',
    signature: '0x...',
    status: 'confirmed',
    blockHeight: 100,
  },
  {
    hash: '0xfedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210',
    from: '0xfedcba9876543210fedcba9876543210fedcba98',
    to: '0x0123456789abcdef0123456789abcdef01234567',
    amount: '500000000000000000',
    nonce: 1,
    timestamp: Date.now() - 7200000,
    gasPrice: '0',
    gasLimit: '21000',
    signature: '0x...',
    status: 'confirmed',
    blockHeight: 95,
  },
];

function SendDialog() {
  const { wallet } = useWallet();
  const [to, setTo] = useState('');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!wallet) return;

    setLoading(true);
    try {
      const amountInWei = BigInt(parseFloat(amount) * 1e18).toString();
      
      const response = await api.submitTransaction({
        from: wallet.address,
        to,
        amount: amountInWei,
        nonce: wallet.nonce,
        signature: '0x...',
      });

      alert(`Transaction submitted! Hash: ${response.txHash}`);
    } catch (error) {
      alert('Failed to send transaction: ' + error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button className="flex-1">
          <Send className="h-4 w-4 mr-2" />
          Send
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Send Tokens</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSend} className="space-y-4">
          <div>
            <Label>Recipient Address</Label>
            <Input
              value={to}
              onChange={(e) => setTo(e.target.value)}
              placeholder="0x..."
            />
          </div>
          <div>
            <Label>Amount</Label>
            <div className="flex gap-2">
              <Input
                type="number"
                step="0.000001"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
              />
              <span className="flex items-center text-sm text-muted-foreground">TOKEN</span>
            </div>
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? 'Sending...' : 'Send'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function ReceiveDialog({ address }: { address: string }) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex-1">
          <QrCode className="h-4 w-4 mr-2" />
          Receive
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Receive Tokens</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center space-y-4">
          <div className="h-48 w-48 bg-muted rounded-lg flex items-center justify-center">
            <QrCode className="h-32 w-32" />
          </div>
          <div className="flex items-center gap-2 p-3 bg-muted rounded-lg w-full">
            <code className="flex-1 text-sm break-all">{address}</code>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigator.clipboard.writeText(address)}
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-sm text-muted-foreground text-center">
            Share this address to receive tokens
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function TransactionCard({ tx, address }: { tx: Transaction; address: string }) {
  const isOutgoing = tx.from.toLowerCase() === address.toLowerCase();
  const statusColors = {
    pending: 'bg-yellow-500',
    processing: 'bg-blue-500',
    confirmed: 'bg-green-500',
    failed: 'bg-red-500',
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${isOutgoing ? 'bg-red-500/10' : 'bg-green-500/10'}`}>
              {isOutgoing ? (
                <Send className="h-5 w-5 text-red-500" />
              ) : (
                <WalletIcon className="h-5 w-5 text-green-500" />
              )}
            </div>
            <div>
              <p className="font-medium">
                {isOutgoing ? 'Sent' : 'Received'}
              </p>
              <p className="text-sm text-muted-foreground">
                {isOutgoing ? 'To: ' : 'From: '}
                {shortenAddress(isOutgoing ? tx.to : tx.from)}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className={`font-medium ${isOutgoing ? 'text-red-500' : 'text-green-500'}`}>
              {isOutgoing ? '-' : '+'}{formatAmount(tx.amount)} TOKEN
            </p>
            <div className="flex items-center justify-end gap-2 mt-1">
              <div className={`h-2 w-2 rounded-full ${statusColors[tx.status]}`} />
              <span className="text-xs capitalize">{tx.status}</span>
            </div>
          </div>
        </div>
        <div className="mt-3 pt-3 border-t flex justify-between text-sm text-muted-foreground">
          <span>{formatTimestamp(tx.timestamp)}</span>
          <a 
            href={`/tx/${tx.hash}`} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center hover:text-primary"
          >
            View <ExternalLink className="h-3 w-3 ml-1" />
          </a>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Wallet() {
  const { wallet, isConnected, connect, disconnect, generateWallet } = useWallet();
  const [privateKey, setPrivateKey] = useState('');
  const [showPrivateKey, setShowPrivateKey] = useState(false);

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await connect(privateKey);
    } catch (error) {
      alert('Invalid private key');
    }
  };

  const handleGenerate = () => {
    const newWallet = generateWallet();
    alert(`New wallet generated!\nAddress: ${newWallet.address}\nPrivate Key: ${newWallet.privateKey}\n\nSave your private key securely!`);
  };

  if (!isConnected) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <WalletIcon className="h-6 w-6" />
              Connect Wallet
            </CardTitle>
            <CardDescription>
              Enter your private key to access your wallet
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleConnect} className="space-y-4">
              <div>
                <Label>Private Key</Label>
                <div className="flex gap-2">
                  <Input
                    type={showPrivateKey ? 'text' : 'password'}
                    value={privateKey}
                    onChange={(e) => setPrivateKey(e.target.value)}
                    placeholder="0x..."
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowPrivateKey(!showPrivateKey)}
                  >
                    <Key className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Never share your private key with anyone. We don't store it on our servers.
                </AlertDescription>
              </Alert>
              <Button type="submit" className="w-full">
                Connect
              </Button>
            </form>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or</span>
              </div>
            </div>

            <Button variant="outline" className="w-full" onClick={handleGenerate}>
              Generate New Wallet
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                <WalletIcon className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">My Wallet</h1>
                <div className="flex items-center gap-2 mt-1">
                  <code className="text-sm text-muted-foreground">{shortenAddress(wallet!.address)}</code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigator.clipboard.writeText(wallet!.address)}
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>
            <Button variant="outline" onClick={disconnect}>
              Disconnect
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <p className="text-sm text-muted-foreground">Total Balance</p>
                <div className="flex items-baseline gap-2 mt-1">
                  <p className="text-4xl font-bold">{formatAmount(wallet!.balance)}</p>
                  <span className="text-lg text-muted-foreground">TOKEN</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  ≈ ${(parseFloat(formatAmount(wallet!.balance)) * 1.25).toFixed(2)} USD
                </p>
              </CardContent>
            </Card>

            <div className="flex gap-4">
              <SendDialog />
              <ReceiveDialog address={wallet!.address} />
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Account Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Nonce</span>
                  <span className="font-medium">{wallet!.nonce}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Network</span>
                  <Badge variant="secondary">Testnet</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Transaction History
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all">
                  <TabsList className="mb-4">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="sent">Sent</TabsTrigger>
                    <TabsTrigger value="received">Received</TabsTrigger>
                  </TabsList>

                  <TabsContent value="all" className="space-y-2">
                    {MOCK_TRANSACTIONS.map(tx => (
                      <TransactionCard key={tx.hash} tx={tx} address={wallet!.address} />
                    ))}
                  </TabsContent>

                  <TabsContent value="sent" className="space-y-2">
                    {MOCK_TRANSACTIONS
                      .filter(tx => tx.from.toLowerCase() === wallet!.address.toLowerCase())
                      .map(tx => (
                        <TransactionCard key={tx.hash} tx={tx} address={wallet!.address} />
                      ))}
                  </TabsContent>

                  <TabsContent value="received" className="space-y-2">
                    {MOCK_TRANSACTIONS
                      .filter(tx => tx.to.toLowerCase() === wallet!.address.toLowerCase())
                      .map(tx => (
                        <TransactionCard key={tx.hash} tx={tx} address={wallet!.address} />
                      ))}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
