/**
 * ============================================
 * Admin Dashboard Page
 * ============================================
 */

import { useState } from 'react';
import { 
  Shield, 
  Users, 
  Box, 
  ArrowRightLeft, 
  Activity,
  Settings,
  Database,
  AlertTriangle,
  CheckCircle,
  XCircle,
  RefreshCw,
  Download,
  Upload
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
// import { Alert } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { AdminStats } from '@/types';

const MOCK_STATS: AdminStats = {
  totalBlocks: 15420,
  totalTransactions: 89345,
  totalAccounts: 1234,
  activeValidators: 3,
  pendingTransactions: 12,
  averageBlockTime: 2.5,
  networkHealth: 'healthy',
};

interface GenesisConfig {
  chainId: string;
  networkId: string;
  genesisTime: number;
  initialSupply: string;
  premine: {
    address: string;
    amount: string;
    description: string;
    vestingMonths: number;
  }[];
  blockTime: number;
  blockReward: string;
  halvingInterval: number;
  validators: {
    id: string;
    publicKey: string;
    address: string;
    stake: string;
    commission: number;
  }[];
}

const MOCK_GENESIS: GenesisConfig = {
  chainId: '1337',
  networkId: 'cloudflare-mvp-testnet',
  genesisTime: Date.now() - 86400000 * 30,
  initialSupply: '10000000000000000000000000',
  premine: [
    { address: '0x0123456789abcdef0123456789abcdef01234567', amount: '1000000000000000000000000', description: 'Team Reserve', vestingMonths: 24 },
    { address: '0xfedcba9876543210fedcba9876543210fedcba98', amount: '500000000000000000000000', description: 'Ecosystem Fund', vestingMonths: 12 },
    { address: '0xaabbccdd11223344aabbccdd11223344aabbccdd', amount: '500000000000000000000000', description: 'Community Rewards', vestingMonths: 0 },
  ],
  blockTime: 3000,
  blockReward: '1000000000000000000',
  halvingInterval: 2100000,
  validators: [
    { id: 'node-0', publicKey: '0x0123456789abcdef...', address: '0x0123456789abcdef0123456789abcdef01234567', stake: '100000000000000000000000', commission: 10 },
    { id: 'node-1', publicKey: '0xfedcba9876543210...', address: '0xfedcba9876543210fedcba9876543210fedcba98', stake: '100000000000000000000000', commission: 10 },
    { id: 'node-2', publicKey: '0xaabbccdd11223344...', address: '0xaabbccdd11223344aabbccdd11223344aabbccdd', stake: '100000000000000000000000', commission: 10 },
  ],
};

function StatCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon,
  trend
}: { 
  title: string; 
  value: string; 
  subtitle?: string;
  icon: React.ElementType;
  trend?: { value: string; positive: boolean };
}) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
            {trend && (
              <p className={`text-xs mt-1 ${trend.positive ? 'text-green-500' : 'text-red-500'}`}>
                {trend.positive ? '↑' : '↓'} {trend.value}
              </p>
            )}
          </div>
          <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
            <Icon className="h-6 w-6 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function HealthStatus({ status }: { status: 'healthy' | 'degraded' | 'down' }) {
  const configs = {
    healthy: { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-500/10', label: 'Healthy' },
    degraded: { icon: AlertTriangle, color: 'text-yellow-500', bg: 'bg-yellow-500/10', label: 'Degraded' },
    down: { icon: XCircle, color: 'text-red-500', bg: 'bg-red-500/10', label: 'Down' },
  };
  
  const config = configs[status];
  const Icon = config.icon;

  return (
    <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${config.bg}`}>
      <Icon className={`h-5 w-5 ${config.color}`} />
      <span className={`font-medium ${config.color}`}>{config.label}</span>
    </div>
  );
}

function ValidatorCard({ validator }: { validator: GenesisConfig['validators'][0] }) {
  const [status] = useState<'online' | 'offline'>('online');

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`h-3 w-3 rounded-full ${status === 'online' ? 'bg-green-500' : 'bg-red-500'}`} />
            <div>
              <p className="font-medium">{validator.id}</p>
              <p className="text-sm text-muted-foreground font-mono">{validator.address.slice(0, 20)}...</p>
            </div>
          </div>
          <Badge variant={status === 'online' ? 'default' : 'destructive'}>
            {status.toUpperCase()}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}

function GenesisConfigDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Settings className="h-4 w-4 mr-2" />
          View Genesis Config
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Genesis Configuration</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Chain ID</Label>
              <Input value={MOCK_GENESIS.chainId} readOnly />
            </div>
            <div>
              <Label>Network ID</Label>
              <Input value={MOCK_GENESIS.networkId} readOnly />
            </div>
          </div>
          
          <div>
            <Label>Genesis Time</Label>
            <Input value={new Date(MOCK_GENESIS.genesisTime).toISOString()} readOnly />
          </div>

          <div>
            <Label>Initial Supply</Label>
            <Input value={`${parseInt(MOCK_GENESIS.initialSupply) / 1e18} TOKEN`} readOnly />
          </div>

          <div className="border-t pt-4">
            <Label className="text-lg font-medium">Premine Allocation</Label>
            <div className="space-y-2 mt-2">
              {MOCK_GENESIS.premine.map((item, i) => (
                <div key={i} className="p-3 bg-muted rounded-lg">
                  <div className="flex justify-between">
                    <span className="font-medium">{item.description}</span>
                    <span>{parseInt(item.amount) / 1e18} TOKEN</span>
                  </div>
                  <p className="text-sm text-muted-foreground font-mono">{item.address}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 border-t pt-4">
            <div>
              <Label>Block Time</Label>
              <Input value={`${MOCK_GENESIS.blockTime}ms`} readOnly />
            </div>
            <div>
              <Label>Block Reward</Label>
              <Input value={`${parseInt(MOCK_GENESIS.blockReward) / 1e18} TOKEN`} readOnly />
            </div>
          </div>

          <div>
            <Label>Halving Interval</Label>
            <Input value={`${MOCK_GENESIS.halvingInterval} blocks`} readOnly />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin123') {
      setIsAuthenticated(true);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-6 w-6" />
              Admin Login
            </CardTitle>
            <CardDescription>
              Enter your password to access the admin dashboard
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label>Password</Label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                />
              </div>
              <Button type="submit" className="w-full">
                Login
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <Shield className="h-8 w-8 text-primary" />
                Admin Dashboard
              </h1>
              <p className="text-muted-foreground mt-1">
                Manage your blockchain network
              </p>
            </div>
            <div className="flex items-center gap-4">
              <HealthStatus status={MOCK_STATS.networkHealth} />
              <GenesisConfigDialog />
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            title="Total Blocks"
            value={MOCK_STATS.totalBlocks.toLocaleString()}
            subtitle={`${MOCK_STATS.averageBlockTime}s avg block time`}
            icon={Box}
            trend={{ value: '12%', positive: true }}
          />
          <StatCard
            title="Total Transactions"
            value={MOCK_STATS.totalTransactions.toLocaleString()}
            subtitle="All time"
            icon={ArrowRightLeft}
            trend={{ value: '8%', positive: true }}
          />
          <StatCard
            title="Total Accounts"
            value={MOCK_STATS.totalAccounts.toLocaleString()}
            subtitle="Active wallets"
            icon={Users}
          />
          <StatCard
            title="Pending Txs"
            value={MOCK_STATS.pendingTransactions.toString()}
            subtitle="In queue"
            icon={Activity}
            trend={{ value: '3', positive: false }}
          />
        </div>

        <Tabs defaultValue="validators" className="space-y-4">
          <TabsList>
            <TabsTrigger value="validators">Validators</TabsTrigger>
            <TabsTrigger value="network">Network</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="validators" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Validator Nodes</h2>
              <Button variant="outline">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh Status
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {MOCK_GENESIS.validators.map(validator => (
                <ValidatorCard key={validator.id} validator={validator} />
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Consensus Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Required Signatures</span>
                      <span className="font-medium">2/3</span>
                    </div>
                    <Progress value={66.67} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Byzantine Fault Tolerance</span>
                      <span className="font-medium">1 node</span>
                    </div>
                    <Progress value={33.33} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="network" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Storage Usage
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">Durable Objects</span>
                        <span className="font-medium">45%</span>
                      </div>
                      <Progress value={45} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">KV Storage</span>
                        <span className="font-medium">12%</span>
                      </div>
                      <Progress value={12} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Network Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">TPS</span>
                      <span className="font-medium">1,234</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Avg Confirmation</span>
                      <span className="font-medium">2.5s</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Success Rate</span>
                      <span className="font-medium text-green-500">99.9%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Network Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Consensus Timeout (ms)</Label>
                      <Input defaultValue="3000" />
                    </div>
                    <div>
                      <Label>Alarm Timeout (ms)</Label>
                      <Input defaultValue="300000" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Max Txs Per Block</Label>
                      <Input defaultValue="20" />
                    </div>
                    <div>
                      <Label>Min Txs Per Block</Label>
                      <Input defaultValue="1" />
                    </div>
                  </div>
                  <Button>
                    <Settings className="h-4 w-4 mr-2" />
                    Save Settings
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Backup & Restore</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export State
                  </Button>
                  <Button variant="outline">
                    <Upload className="h-4 w-4 mr-2" />
                    Import State
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
