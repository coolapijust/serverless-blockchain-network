/**
 * ============================================
 * Exchange Page
 * ============================================
 */

import { useState } from 'react';
import { 
  ArrowUpDown, 
  Wallet, 
  History,
  CandlestickChart,
  Plus,
  Minus
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useWallet } from '@/contexts/WalletContext';
import { formatAmount } from '@/lib/crypto';
import type { MarketData, Order, Trade } from '@/types';

// 模拟市场数据
const MOCK_MARKET_DATA: MarketData = {
  price: '1.25',
  change24h: '+5.23',
  volume24h: '1250000',
  high24h: '1.35',
  low24h: '1.18',
  lastUpdate: Date.now(),
};

// 模拟订单簿
const MOCK_ORDERS: Order[] = [
  { id: '1', type: 'sell', amount: '1000', price: '1.26', filled: '0', status: 'open', timestamp: Date.now() - 10000, owner: '0x1234...' },
  { id: '2', type: 'sell', amount: '500', price: '1.25', filled: '0', status: 'open', timestamp: Date.now() - 20000, owner: '0x5678...' },
  { id: '3', type: 'buy', amount: '800', price: '1.24', filled: '0', status: 'open', timestamp: Date.now() - 30000, owner: '0x9abc...' },
  { id: '4', type: 'buy', amount: '1200', price: '1.23', filled: '0', status: 'open', timestamp: Date.now() - 40000, owner: '0xdef0...' },
];

// 模拟交易历史
const MOCK_TRADES: Trade[] = [
  { id: '1', type: 'buy', amount: '100', price: '1.25', total: '125', timestamp: Date.now() - 60000, from: '0x1234...', to: '0x5678...', txHash: '0xabcd...' },
  { id: '2', type: 'sell', amount: '50', price: '1.24', total: '62', timestamp: Date.now() - 120000, from: '0x9abc...', to: '0xdef0...', txHash: '0xef01...' },
  { id: '3', type: 'buy', amount: '200', price: '1.26', total: '252', timestamp: Date.now() - 180000, from: '0x2345...', to: '0x6789...', txHash: '0x1234...' },
];

function PriceChart() {
  const points = [30, 45, 35, 50, 40, 55, 45, 60, 50, 65, 55, 70];
  const max = Math.max(...points);
  const min = Math.min(...points);
  const range = max - min;
  
  const pathPoints = points.map((p, i) => {
    const x = (i / (points.length - 1)) * 100;
    const y = 100 - ((p - min) / range) * 80 - 10;
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="h-64 w-full bg-card rounded-lg p-4">
      <svg viewBox="0 0 100 100" className="w-full h-full" preserveAspectRatio="none">
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.3" />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0" />
          </linearGradient>
        </defs>
        <polygon
          points={`0,100 ${pathPoints} 100,100`}
          fill="url(#gradient)"
        />
        <polyline
          points={pathPoints}
          fill="none"
          stroke="hsl(var(--primary))"
          strokeWidth="0.5"
        />
      </svg>
    </div>
  );
}

function OrderBook() {
  const sellOrders = MOCK_ORDERS.filter(o => o.type === 'sell').sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
  const buyOrders = MOCK_ORDERS.filter(o => o.type === 'buy').sort((a, b) => parseFloat(b.price) - parseFloat(a.price));

  return (
    <div className="space-y-4">
      <div>
        <p className="text-sm font-medium text-red-500 mb-2">Sell Orders</p>
        <div className="space-y-1">
          {sellOrders.map(order => (
            <div key={order.id} className="flex justify-between text-sm p-2 bg-red-500/5 rounded">
              <span className="text-red-500">{order.price}</span>
              <span>{formatAmount(order.amount)}</span>
              <span className="text-muted-foreground">${(parseFloat(order.price) * parseFloat(order.amount)).toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="text-center">
        <span className="text-2xl font-bold text-primary">{MOCK_MARKET_DATA.price}</span>
        <span className="text-sm text-green-500 ml-2">{MOCK_MARKET_DATA.change24h}%</span>
      </div>

      <div>
        <p className="text-sm font-medium text-green-500 mb-2">Buy Orders</p>
        <div className="space-y-1">
          {buyOrders.map(order => (
            <div key={order.id} className="flex justify-between text-sm p-2 bg-green-500/5 rounded">
              <span className="text-green-500">{order.price}</span>
              <span>{formatAmount(order.amount)}</span>
              <span className="text-muted-foreground">${(parseFloat(order.price) * parseFloat(order.amount)).toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function TradingForm({ type }: { type: 'buy' | 'sell' }) {
  const { wallet } = useWallet();
  const [amount, setAmount] = useState('');
  const [price, setPrice] = useState(MOCK_MARKET_DATA.price);

  const total = amount && price ? (parseFloat(amount) * parseFloat(price)).toFixed(2) : '0';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`${type === 'buy' ? 'Buy' : 'Sell'} order submitted: ${amount} @ ${price}`);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="text-sm font-medium">Price (USD)</label>
        <div className="flex items-center gap-2 mt-1">
          <Input
            type="number"
            step="0.01"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="0.00"
          />
          <span className="text-sm text-muted-foreground">USD</span>
        </div>
      </div>

      <div>
        <label className="text-sm font-medium">Amount</label>
        <div className="flex items-center gap-2 mt-1">
          <Input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
          />
          <span className="text-sm text-muted-foreground">TOKEN</span>
        </div>
      </div>

      <div className="p-3 bg-muted rounded-lg">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Total</span>
          <span className="font-medium">${total} USD</span>
        </div>
      </div>

      {wallet ? (
        <Button 
          type="submit" 
          className="w-full"
          variant={type === 'buy' ? 'default' : 'destructive'}
        >
          {type === 'buy' ? (
            <><Plus className="h-4 w-4 mr-2" /> Buy TOKEN</>
          ) : (
            <><Minus className="h-4 w-4 mr-2" /> Sell TOKEN</>
          )}
        </Button>
      ) : (
        <Button type="button" className="w-full" variant="outline" disabled>
          Connect Wallet to Trade
        </Button>
      )}
    </form>
  );
}

export default function Exchange() {
  const [activeTab, setActiveTab] = useState('buy');

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <CandlestickChart className="h-8 w-8 text-primary" />
                Exchange
              </h1>
              <p className="text-muted-foreground mt-1">
                Trade TOKEN with zero gas fees
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-2xl font-bold">{MOCK_MARKET_DATA.price} USD</p>
                <p className={`text-sm ${MOCK_MARKET_DATA.change24h.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>
                  {MOCK_MARKET_DATA.change24h} (24h)
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">24h High</p>
                  <p className="text-lg font-medium">{MOCK_MARKET_DATA.high24h} USD</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">24h Low</p>
                  <p className="text-lg font-medium">{MOCK_MARKET_DATA.low24h} USD</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">24h Volume</p>
                  <p className="text-lg font-medium">{formatAmount(MOCK_MARKET_DATA.volume24h)}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">Market Cap</p>
                  <p className="text-lg font-medium">$1.25M</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Price Chart</CardTitle>
              </CardHeader>
              <CardContent>
                <PriceChart />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Recent Trades
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {MOCK_TRADES.map(trade => (
                    <div key={trade.id} className="flex justify-between items-center p-2 hover:bg-muted rounded">
                      <div className="flex items-center gap-2">
                        <Badge variant={trade.type === 'buy' ? 'default' : 'destructive'}>
                          {trade.type.toUpperCase()}
                        </Badge>
                        <span className="text-sm">{formatAmount(trade.amount)} TOKEN</span>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">{trade.price} USD</p>
                        <p className="text-xs text-muted-foreground">${trade.total}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowUpDown className="h-5 w-5" />
                  Order Book
                </CardTitle>
              </CardHeader>
              <CardContent>
                <OrderBook />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="h-5 w-5" />
                  Trade
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="buy" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                      Buy
                    </TabsTrigger>
                    <TabsTrigger value="sell" className="data-[state=active]:bg-red-500 data-[state=active]:text-white">
                      Sell
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="buy" className="mt-4">
                    <TradingForm type="buy" />
                  </TabsContent>
                  <TabsContent value="sell" className="mt-4">
                    <TradingForm type="sell" />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
