/**
 * ============================================
 * Wallet Context
 * ============================================
 */

import React, { createContext, useContext, useState, useCallback } from 'react';
import type { Address } from '@/types';

interface Wallet {
  address: Address;
  publicKey: string;
  privateKey: string;
  balance: string;
  nonce: number;
}

interface WalletContextType {
  wallet: Wallet | null;
  isConnected: boolean;
  connect: (privateKey: string) => Promise<void>;
  disconnect: () => void;
  refreshBalance: () => Promise<void>;
  generateWallet: () => Wallet;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: React.ReactNode }) {
  const [wallet, setWallet] = useState<Wallet | null>(null);

  const generateWallet = useCallback((): Wallet => {
    // 生成随机私钥（演示用）
    const privateKey = '0x' + Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
    
    // 从私钥派生公钥（简化）
    const publicKey = '0x' + Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
    
    // 从公钥派生地址（前20字节）
    const address = '0x' + publicKey.slice(2, 42);

    return {
      address,
      publicKey,
      privateKey,
      balance: '0',
      nonce: 0,
    };
  }, []);

  const connect = useCallback(async (privateKey: string) => {
    // 验证私钥格式
    if (!privateKey.startsWith('0x') || privateKey.length !== 66) {
      throw new Error('Invalid private key format');
    }

    // 派生公钥和地址（简化实现）
    const publicKey = '0x' + privateKey.slice(2, 66).split('').reverse().join('').slice(0, 64);
    const address = '0x' + publicKey.slice(2, 42);

    setWallet({
      address,
      publicKey,
      privateKey,
      balance: '0',
      nonce: 0,
    });
  }, []);

  const disconnect = useCallback(() => {
    setWallet(null);
  }, []);

  const refreshBalance = useCallback(async () => {
    if (!wallet) return;
    
    // 调用 API 获取最新余额
    try {
      const response = await fetch(`/api/account/${wallet.address}`);
      const data = await response.json();
      
      if (data.success) {
        setWallet(prev => prev ? {
          ...prev,
          balance: data.data.balance,
          nonce: data.data.nonce,
        } : null);
      }
    } catch (error) {
      console.error('Failed to refresh balance:', error);
    }
  }, [wallet?.address]);

  return (
    <WalletContext.Provider
      value={{
        wallet,
        isConnected: !!wallet,
        connect,
        disconnect,
        refreshBalance,
        generateWallet,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
}
