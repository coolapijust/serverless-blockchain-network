/**
 * ============================================
 * Client-side Crypto Utilities
 * ============================================
 */

import type { HexString } from '@/types';

export function hexToBytes(hex: HexString): Uint8Array {
  const cleanHex = hex.startsWith('0x') ? hex.slice(2) : hex;
  const bytes = new Uint8Array(cleanHex.length / 2);
  for (let i = 0; i < cleanHex.length; i += 2) {
    bytes[i / 2] = parseInt(cleanHex.slice(i, i + 2), 16);
  }
  return bytes;
}

export function bytesToHex(bytes: Uint8Array): HexString {
  return '0x' + Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

export function stringToBytes(str: string): Uint8Array {
  return new TextEncoder().encode(str);
}

export async function sha256Hex(data: string): Promise<HexString> {
  const encoder = new TextEncoder();
  const hashBuffer = await crypto.subtle.digest('SHA-256', encoder.encode(data));
  return bytesToHex(new Uint8Array(hashBuffer));
}

/**
 * 创建交易签名数据
 */
export function createSignData(tx: {
  from: string;
  to: string;
  amount: string;
  nonce: number;
  timestamp: number;
}): string {
  const data = {
    from: tx.from.toLowerCase(),
    to: tx.to.toLowerCase(),
    amount: tx.amount,
    nonce: tx.nonce,
    timestamp: tx.timestamp,
  };
  return JSON.stringify(data, Object.keys(data).sort());
}

/**
 * 验证地址格式
 */
export function isValidAddress(address: string): boolean {
  if (!address) return false;
  const clean = address.startsWith('0x') ? address.slice(2) : address;
  if (clean.length !== 40) return false;
  return /^[0-9a-fA-F]+$/.test(clean);
}

/**
 * 缩短地址显示
 */
export function shortenAddress(address: string, chars: number = 6): string {
  if (!address || address.length < chars * 2 + 2) return address;
  return `${address.slice(0, chars + 2)}...${address.slice(-chars)}`;
}

/**
 * 格式化金额显示
 */
export function formatAmount(amount: string, decimals: number = 18): string {
  const value = BigInt(amount);
  const divisor = BigInt(10) ** BigInt(decimals);
  const integerPart = (value / divisor).toString();
  const fractionalPart = (value % divisor).toString().padStart(decimals, '0');
  
  // 截取前 6 位小数
  const trimmed = fractionalPart.slice(0, 6).replace(/0+$/, '');
  
  return trimmed ? `${integerPart}.${trimmed}` : integerPart;
}

/**
 * 格式化时间戳
 */
export function formatTimestamp(timestamp: number): string {
  const date = new Date(timestamp);
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

/**
 * 计算时间差
 */
export function timeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days}天前`;
  if (hours > 0) return `${hours}小时前`;
  if (minutes > 0) return `${minutes}分钟前`;
  return `${seconds}秒前`;
}

/**
 * 生成随机 nonce
 */
export function generateNonce(): number {
  return Math.floor(Math.random() * 1000000);
}
