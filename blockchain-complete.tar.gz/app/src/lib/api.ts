/**
 * ============================================
 * Blockchain API Client
 * ============================================
 */

import type {
  Transaction,
  Block,
  Account,
  NetworkStatus,
  HexString,
  Address,
} from '@/types';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://api.blockchain-mvp.workers.dev';

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  requestId: string;
}

class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string = API_BASE_URL) {
    this.baseUrl = baseUrl;
  }

  private async fetch<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || `HTTP ${response.status}`);
    }

    const result = await response.json() as ApiResponse<T>;
    
    if (!result.success) {
      throw new Error(result.error || 'API request failed');
    }

    return result.data as T;
  }

  // ==================== Network ====================
  async getNetworkStatus(): Promise<NetworkStatus> {
    return this.fetch('/status');
  }

  async getHealth(): Promise<{ status: string; service: string }> {
    const response = await fetch(`${this.baseUrl}/health`);
    return response.json();
  }

  // ==================== Blocks ====================
  async getLatestBlock(): Promise<Block> {
    return this.fetch('/block/latest');
  }

  async getBlock(height: number): Promise<Block> {
    return this.fetch(`/block/${height}`);
  }

  async getBlocks(page: number = 1, limit: number = 20): Promise<Block[]> {
    const status = await this.getNetworkStatus();
    const blocks: Block[] = [];
    
    const startHeight = Math.max(0, status.latestBlockHeight - (page - 1) * limit);
    const endHeight = Math.max(0, startHeight - limit);
    
    for (let i = startHeight; i > endHeight; i--) {
      try {
        const block = await this.getBlock(i);
        blocks.push(block);
      } catch (e) {
        break;
      }
    }
    
    return blocks;
  }

  // ==================== Transactions ====================
  async getTransaction(txHash: HexString): Promise<Transaction> {
    return this.fetch(`/tx/${txHash}`);
  }

  async submitTransaction(tx: {
    from: Address;
    to: Address;
    amount: string;
    nonce: number;
    signature: string;
  }): Promise<{ txHash: string; estimatedConfirmationTime: number }> {
    return this.fetch('/tx/submit', {
      method: 'POST',
      body: JSON.stringify({
        ...tx,
        timestamp: Date.now(),
      }),
    });
  }

  // ==================== Accounts ====================
  async getAccount(address: Address): Promise<Account> {
    return this.fetch(`/account/${address}`);
  }

  // ==================== Faucet ====================
  async requestFaucet(address: Address): Promise<{ txHash: string; amount: string }> {
    return this.fetch('/faucet', {
      method: 'POST',
      body: JSON.stringify({ address }),
    });
  }
}

export const api = new ApiClient();
export default api;
