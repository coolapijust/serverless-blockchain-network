/**
 * ============================================
 * Cloudflare Serverless Blockchain MVP
 * 加密工具库 - Ed25519 + SHA-256
 * ============================================
 * 
 * 设计原则：
 * 1. 所有加密操作使用 Web Crypto API（Cloudflare Workers 原生支持）
 * 2. Ed25519 用于签名（比 ECDSA 更快，密钥更短）
 * 3. SHA-256 用于哈希
 * 4. 所有数据使用 Uint8Array 处理，避免编码问题
 */

import type { HexString, Signature, Address, TxHash, BlockHash, KeyPair } from './types';

// ============================================
// 编码工具
// ============================================

/**
 * 将十六进制字符串转为 Uint8Array
 */
export function hexToBytes(hex: HexString): Uint8Array {
  // 移除 0x 前缀
  const cleanHex = hex.startsWith('0x') ? hex.slice(2) : hex;
  
  if (cleanHex.length % 2 !== 0) {
    throw new Error('Invalid hex string: length must be even');
  }
  
  const bytes = new Uint8Array(cleanHex.length / 2);
  for (let i = 0; i < cleanHex.length; i += 2) {
    bytes[i / 2] = parseInt(cleanHex.slice(i, i + 2), 16);
  }
  return bytes;
}

/**
 * 将 Uint8Array 转为十六进制字符串
 */
export function bytesToHex(bytes: Uint8Array): HexString {
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * 为十六进制字符串添加 0x 前缀
 */
export function addHexPrefix(hex: string): HexString {
  return hex.startsWith('0x') ? hex : `0x${hex}`;
}

/**
 * 将字符串转为 Uint8Array
 */
export function stringToBytes(str: string): Uint8Array {
  return new TextEncoder().encode(str);
}

/**
 * 将对象转为 JSON 字符串然后哈希
 */
export function objectToBytes(obj: unknown): Uint8Array {
  // 按 key 排序确保确定性
  const sorted = JSON.stringify(obj, Object.keys(obj as object).sort());
  return stringToBytes(sorted);
}

// ============================================
// SHA-256 哈希
// ============================================

/**
 * 计算 SHA-256 哈希
 */
export async function sha256(data: Uint8Array | string): Promise<Uint8Array> {
  const bytes = typeof data === 'string' ? stringToBytes(data) : data;
  const hashBuffer = await crypto.subtle.digest('SHA-256', bytes);
  return new Uint8Array(hashBuffer);
}

/**
 * 计算 SHA-256 哈希并返回十六进制字符串
 */
export async function sha256Hex(data: Uint8Array | string): Promise<HexString> {
  const hash = await sha256(data);
  return addHexPrefix(bytesToHex(hash));
}

/**
 * 计算交易哈希
 */
export async function hashTransaction(tx: {
  from: string;
  to: string;
  amount: string;
  nonce: number;
  timestamp: number;
  gasPrice: string;
  gasLimit: string;
}): Promise<TxHash> {
  // 按固定字段顺序哈希，确保一致性
  const txData = {
    from: tx.from.toLowerCase(),
    to: tx.to.toLowerCase(),
    amount: tx.amount,
    nonce: tx.nonce,
    timestamp: tx.timestamp,
    gasPrice: tx.gasPrice,
    gasLimit: tx.gasLimit,
  };
  return sha256Hex(objectToBytes(txData));
}

/**
 * 计算区块哈希
 */
export async function hashBlock(header: {
  height: number;
  timestamp: number;
  prevHash: string;
  txRoot: string;
  stateRoot: string;
  proposer: string;
  txCount: number;
}): Promise<BlockHash> {
  const headerData = {
    height: header.height,
    timestamp: header.timestamp,
    prevHash: header.prevHash.toLowerCase(),
    txRoot: header.txRoot.toLowerCase(),
    stateRoot: header.stateRoot.toLowerCase(),
    proposer: header.proposer,
    txCount: header.txCount,
  };
  return sha256Hex(objectToBytes(headerData));
}

/**
 * 计算默克尔根
 * 简单实现：两两哈希直到只剩一个
 */
export async function computeMerkleRoot(hashes: HexString[]): Promise<BlockHash> {
  if (hashes.length === 0) {
    // 空区块的默克尔根
    return sha256Hex('');
  }
  
  if (hashes.length === 1) {
    return hashes[0];
  }
  
  // 补齐到 2 的幂次
  let level = hashes.map(h => hexToBytes(h));
  
  while (level.length > 1) {
    const nextLevel: Uint8Array[] = [];
    
    for (let i = 0; i < level.length; i += 2) {
      if (i + 1 < level.length) {
        // 合并两个哈希
        const combined = new Uint8Array(64);
        combined.set(level[i], 0);
        combined.set(level[i + 1], 32);
        nextLevel.push(await sha256(combined));
      } else {
        // 奇数个，复制最后一个
        nextLevel.push(level[i]);
      }
    }
    
    level = nextLevel;
  }
  
  return addHexPrefix(bytesToHex(level[0]));
}

// ============================================
// Ed25519 签名
// ============================================

// Ed25519 算法标识
const ED25519_ALGORITHM = 'Ed25519';

/**
 * 生成 Ed25519 密钥对
 */
export async function generateKeyPair(): Promise<KeyPair> {
  const keyPair = await crypto.subtle.generateKey(
    ED25519_ALGORITHM,
    true, // extractable
    ['sign', 'verify']
  );
  
  const privateKeyJwk = await crypto.subtle.exportKey('jwk', keyPair.privateKey);
  const publicKeyJwk = await crypto.subtle.exportKey('jwk', keyPair.publicKey);
  
  // JWK 中 d 是私钥，x 是公钥
  return {
    privateKey: addHexPrefix(privateKeyJwk.d!),
    publicKey: addHexPrefix(publicKeyJwk.x!),
  };
}

/**
 * 从私钥导入密钥对
 * 注意：Ed25519 私钥包含公钥信息
 */
export async function importKeyPairFromPrivateKey(privateKeyHex: HexString): Promise<KeyPair> {
  const privateKeyBytes = hexToBytes(privateKeyHex);
  
  // Ed25519 私钥是 32 字节，扩展为 64 字节（私钥 + 公钥）用于导入
  // 但实际上 Web Crypto API 需要 JWK 格式
  
  // 先计算公钥
  const privateKey = await crypto.subtle.importKey(
    'raw',
    privateKeyBytes,
    ED25519_ALGORITHM,
    true,
    ['sign']
  );
  
  // 导出 JWK 获取公钥
  const privateJwk = await crypto.subtle.exportKey('jwk', privateKey);
  
  // 重新导入完整的密钥对
  const fullKeyPair = await crypto.subtle.generateKey(
    ED25519_ALGORITHM,
    true,
    ['sign', 'verify']
  );
  
  // 实际部署时应该使用预生成的密钥
  // 这里简化处理，返回原始私钥和计算的公钥
  const publicKey = privateJwk.x!;
  
  return {
    privateKey: addHexPrefix(privateKeyHex),
    publicKey: addHexPrefix(publicKey),
  };
}

/**
 * 从十六进制导入公钥
 */
export async function importPublicKey(publicKeyHex: HexString): Promise<CryptoKey> {
  const publicKeyBytes = hexToBytes(publicKeyHex);
  
  return crypto.subtle.importKey(
    'raw',
    publicKeyBytes,
    ED25519_ALGORITHM,
    false, // 公钥不需要 extractable
    ['verify']
  );
}

/**
 * 从十六进制导入私钥
 */
export async function importPrivateKey(privateKeyHex: HexString): Promise<CryptoKey> {
  const privateKeyBytes = hexToBytes(privateKeyHex);
  
  // Web Crypto API 的 Ed25519 需要 JWK 格式
  // 这里我们假设输入是 32 字节的种子
  const jwk = {
    kty: 'OKP',
    crv: 'Ed25519',
    d: privateKeyHex.replace('0x', ''),
    x: '', // 需要计算
  };
  
  return crypto.subtle.importKey(
    'jwk',
    jwk,
    ED25519_ALGORITHM,
    false,
    ['sign']
  );
}

/**
 * 使用私钥签名消息
 */
export async function signMessage(
  message: Uint8Array | string,
  privateKey: CryptoKey
): Promise<Signature> {
  const bytes = typeof message === 'string' ? stringToBytes(message) : message;
  
  const signature = await crypto.subtle.sign(
    ED25519_ALGORITHM,
    privateKey,
    bytes
  );
  
  return addHexPrefix(bytesToHex(new Uint8Array(signature)));
}

/**
 * 使用私钥（十六进制）签名消息
 */
export async function signWithPrivateKey(
  message: Uint8Array | string,
  privateKeyHex: HexString
): Promise<Signature> {
  // 简化实现：直接使用 raw 格式导入
  const privateKeyBytes = hexToBytes(privateKeyHex);
  
  const privateKey = await crypto.subtle.importKey(
    'raw',
    privateKeyBytes,
    ED25519_ALGORITHM,
    false,
    ['sign']
  );
  
  return signMessage(message, privateKey);
}

/**
 * 验证签名
 */
export async function verifySignature(
  message: Uint8Array | string,
  signature: Signature,
  publicKey: CryptoKey | HexString
): Promise<boolean> {
  try {
    const bytes = typeof message === 'string' ? stringToBytes(message) : message;
    const signatureBytes = hexToBytes(signature);
    
    const key = typeof publicKey === 'string' 
      ? await importPublicKey(publicKey)
      : publicKey;
    
    return crypto.subtle.verify(
      ED25519_ALGORITHM,
      key,
      signatureBytes,
      bytes
    );
  } catch (error) {
    console.error('Signature verification error:', error);
    return false;
  }
}

// ============================================
// 地址生成
// ============================================

/**
 * 从公钥生成地址
 * 取公钥前 20 字节（40 个十六进制字符）
 */
export function publicKeyToAddress(publicKey: HexString): Address {
  const cleanKey = publicKey.startsWith('0x') ? publicKey.slice(2) : publicKey;
  // 取前 40 个字符（20 字节）
  const address = cleanKey.slice(0, 40).toLowerCase();
  return addHexPrefix(address);
}

/**
 * 验证地址格式
 */
export function isValidAddress(address: string): boolean {
  if (!address) return false;
  
  const clean = address.startsWith('0x') ? address.slice(2) : address;
  
  // 必须是 40 个十六进制字符
  if (clean.length !== 40) return false;
  
  // 必须是有效的十六进制
  return /^[0-9a-fA-F]+$/.test(clean);
}

// ============================================
// 交易签名与验证
// ============================================

/**
 * 创建待签名交易数据
 */
export function createSignData(tx: {
  from: string;
  to: string;
  amount: string;
  nonce: number;
  timestamp: number;
}): string {
  // 按固定格式序列化
  const data = {
    from: tx.from.toLowerCase(),
    to: tx.to.toLowerCase(),
    amount: tx.amount,
    nonce: tx.nonce,
    timestamp: tx.timestamp,
  };
  
  // 使用 RFC 8785 (JSON Canonicalization Scheme) 风格
  return JSON.stringify(data, Object.keys(data).sort());
}

/**
 * 签名交易
 */
export async function signTransaction(
  tx: {
    from: string;
    to: string;
    amount: string;
    nonce: number;
    timestamp: number;
  },
  privateKeyHex: HexString
): Promise<Signature> {
  const signData = createSignData(tx);
  return signWithPrivateKey(signData, privateKeyHex);
}

/**
 * 验证交易签名
 * 从签名恢复公钥并验证
 */
export async function verifyTransactionSignature(
  tx: {
    from: string;
    to: string;
    amount: string;
    nonce: number;
    timestamp: number;
    signature: string;
  },
  publicKeyHex: HexString
): Promise<boolean> {
  const signData = createSignData(tx);
  return verifySignature(signData, tx.signature, publicKeyHex);
}

// ============================================
// 区块签名
// ============================================

/**
 * 创建区块签名数据
 */
export function createBlockSignData(blockHash: BlockHash): string {
  return `block:${blockHash}`;
}

/**
 * 签名区块
 */
export async function signBlock(
  blockHash: BlockHash,
  privateKeyHex: HexString
): Promise<Signature> {
  const signData = createBlockSignData(blockHash);
  return signWithPrivateKey(signData, privateKeyHex);
}

/**
 * 验证区块签名
 */
export async function verifyBlockSignature(
  blockHash: BlockHash,
  signature: Signature,
  publicKeyHex: HexString
): Promise<boolean> {
  const signData = createBlockSignData(blockHash);
  return verifySignature(signData, signature, publicKeyHex);
}

// ============================================
// 工具函数
// ============================================

/**
 * 生成随机 nonce
 */
export function generateNonce(): number {
  return Math.floor(Math.random() * 1000000);
}

/**
 * 生成随机私钥（用于测试）
 * 注意：这不是密码学安全的随机数生成器，仅用于测试
 */
export function generateRandomPrivateKey(): HexString {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return addHexPrefix(bytesToHex(bytes));
}

/**
 * 预定义的测试密钥（用于开发和测试）
 * 生产环境务必使用 wrangler secret 管理
 */
export const TEST_KEY_PAIRS: KeyPair[] = [
  {
    // Proposer 密钥
    privateKey: '0x0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef',
    publicKey: '0x0123456789abcdef0123456789abcdef01234567',
  },
  {
    // Validator 1 密钥
    privateKey: '0xfedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210',
    publicKey: '0xfedcba9876543210fedcba9876543210fedcba98',
  },
  {
    // Validator 2 密钥
    privateKey: '0xaabbccdd11223344aabbccdd11223344aabbccdd11223344aabbccdd11223344',
    publicKey: '0xaabbccdd11223344aabbccdd11223344aabbccdd',
  },
];

/**
 * 获取测试密钥对
 */
export function getTestKeyPair(index: number): KeyPair {
  if (index < 0 || index >= TEST_KEY_PAIRS.length) {
    throw new Error(`Invalid key pair index: ${index}`);
  }
  return TEST_KEY_PAIRS[index];
}
